import { Post, IPost } from '../../models/Post';
import { Like } from '../../models/Like';
import { SavedPost } from '../../models/SavedPost';
import { User } from '../../models/User';
import { Notification } from '../../models/Notification';
import { requireUser } from '../../middleware/auth';
import {
  toObjectId,
  isValidId,
  isPostLiked,
  isPostSaved,
  getPostLikesCount,
} from './helpers';

export const postResolvers = {
  Post: {
    author: (parent: IPost) => User.findById(parent.authorId),
    isLiked: (parent: IPost, _: any, context: any) =>
      context.user ? isPostLiked(context.user.id, String(parent._id)) : false,
    isSaved: (parent: IPost, _: any, context: any) =>
      context.user ? isPostSaved(context.user.id, String(parent._id)) : false,
    likesCount: (parent: IPost) => getPostLikesCount(String(parent._id)),
    commentsCount: () => 0, // comments not implemented in this phase
  },

  Query: {
    posts: async (_: any, { limit, offset }: { limit: number; offset: number }, context: any) => {
      requireUser(context);
      return Post.find().sort({ createdAt: -1 }).skip(offset).limit(limit);
    },

    post: async (_: any, { id }: { id: string }, context: any) => {
      requireUser(context);
      if (!isValidId(id)) throw new Error('Invalid post id.');
      const post = await Post.findById(id);
      if (!post) throw new Error('Post not found.');
      return post;
    },

    userPosts: async (_: any, { userId, limit, offset }: any, context: any) => {
      requireUser(context);
      if (!isValidId(userId)) throw new Error('Invalid user id.');
      return Post.find({ authorId: toObjectId(userId) })
        .sort({ createdAt: -1 })
        .skip(offset)
        .limit(limit);
    },

    savedPosts: async (_: any, { limit, offset }: { limit: number; offset: number }, context: any) => {
      const user = requireUser(context);
      const saved = await SavedPost.find({ userId: toObjectId(user.id) })
        .sort({ createdAt: -1 })
        .skip(offset)
        .limit(limit);
      const postIds = saved.map((s) => s.postId);
      if (!postIds.length) return [];
      // Preserve order of saved records.
      const posts = await Post.find({ _id: { $in: postIds } });
      const byId = new Map(posts.map((p) => [String(p._id), p]));
      return postIds.map((id) => byId.get(String(id))).filter(Boolean) as IPost[];
    },
  },

  Mutation: {
    createPost: async (_: any, { input }: any, context: any) => {
      const user = requireUser(context);
      if (!input.caption && (!input.media || !input.media.length)) {
        throw new Error('A post must have a caption or media.');
      }
      const media = (input.media || []).map((m: any) => ({
        url: m.url,
        type: m.type || 'image',
      }));
      const post = await Post.create({
        authorId: toObjectId(user.id),
        caption: input.caption || '',
        media,
      });
      return post;
    },

    updatePost: async (_: any, { id, input }: any, context: any) => {
      const user = requireUser(context);
      if (!isValidId(id)) throw new Error('Invalid post id.');
      const post = await Post.findById(id);
      if (!post) throw new Error('Post not found.');
      if (String(post.authorId) !== user.id) {
        throw new Error('Unauthorized: you can only edit your own posts.');
      }
      if (input.caption !== undefined) post.caption = input.caption;
      if (input.media !== undefined) {
        post.media = input.media.map((m: any) => ({ url: m.url, type: m.type || 'image' }));
      }
      await post.save();
      return post;
    },

    deletePost: async (_: any, { id }: { id: string }, context: any) => {
      const user = requireUser(context);
      if (!isValidId(id)) throw new Error('Invalid post id.');
      const post = await Post.findById(id);
      if (!post) throw new Error('Post not found.');
      if (String(post.authorId) !== user.id) {
        throw new Error('Unauthorized: you can only delete your own posts.');
      }
      await post.deleteOne();
      // Clean up dependent likes and saves.
      await Like.deleteMany({ postId: toObjectId(id) });
      await SavedPost.deleteMany({ postId: toObjectId(id) });
      return true;
    },

    likePost: async (_: any, { postId }: { postId: string }, context: any) => {
      const user = requireUser(context);
      if (!isValidId(postId)) throw new Error('Invalid post id.');
      const post = await Post.findById(postId);
      if (!post) throw new Error('Post not found.');

      const existing = await Like.findOne({
        userId: toObjectId(user.id),
        postId: toObjectId(postId),
      });
      if (existing) throw new Error('You have already liked this post.');

      await Like.create({ userId: toObjectId(user.id), postId: toObjectId(postId) });

      if (String(post.authorId) !== user.id) {
        await Notification.create({
          recipientId: post.authorId,
          senderId: toObjectId(user.id),
          type: 'LIKE',
          referenceId: toObjectId(postId),
          message: 'liked your post.',
        });
      }
      return post;
    },

    unlikePost: async (_: any, { postId }: { postId: string }, context: any) => {
      const user = requireUser(context);
      if (!isValidId(postId)) throw new Error('Invalid post id.');
      const post = await Post.findById(postId);
      if (!post) throw new Error('Post not found.');
      await Like.deleteOne({ userId: toObjectId(user.id), postId: toObjectId(postId) });
      return post;
    },

    savePost: async (_: any, { postId }: { postId: string }, context: any) => {
      const user = requireUser(context);
      if (!isValidId(postId)) throw new Error('Invalid post id.');
      const post = await Post.findById(postId);
      if (!post) throw new Error('Post not found.');
      const existing = await SavedPost.findOne({
        userId: toObjectId(user.id),
        postId: toObjectId(postId),
      });
      if (existing) throw new Error('Post already saved.');
      await SavedPost.create({ userId: toObjectId(user.id), postId: toObjectId(postId) });
      return true;
    },

    unsavePost: async (_: any, { postId }: { postId: string }, context: any) => {
      const user = requireUser(context);
      if (!isValidId(postId)) throw new Error('Invalid post id.');
      await SavedPost.deleteOne({ userId: toObjectId(user.id), postId: toObjectId(postId) });
      return true;
    },
  },
};
